/* 
Author: Saul Canche Marcial 
Copilador: Zinjai
Version: 1.0
Sistema operativo: Linux ubuntu
Fecha de cracion: 7 de junio 2023
Descripcion: 
Ejemplo de como funciona la division entre diferentes tipos de datos  

*/ 
#include <stdio.h>
int main(){
    //la entrada seria 5/2 asi como el proceso
    //salida
    printf("division enterea 5/2 es %7d\n", 5/2);
    printf("division flotante: 5./2. es %7.2f\n", 5./2.);
    printf("division mixta 5./2 es %7.2f", 5./2);
    return 0;
}
